#include "inverted.h"

/* Function to save database into a file */
void save_database(M_node *HT[], char *file)
{
    // Check file extension
    char *res = strstr(file, ".");
    FILE *fptr = NULL;

    // Validate .txt file
    if(res && !strcmp(res, ".txt"))
    {
        // Open file in write mode
        fptr = fopen(file, "w");

        if(fptr == NULL)
        {
            printf("\nERROR : Unable to create file\n");
            return;
        }
    }
    else
    {
        // Invalid extension
        printf("\nINFO : %s => Please use .txt extension\n", file);
        return;
    } 

    // Traverse all hash table indexes
    for(int i = 0; i < 27; i++)
    {
        // Check if index has data
        if(HT[i] != NULL)
        {
            // Traverse main linked list (words)
            M_node *main_temp = HT[i];

            while(main_temp != NULL)
            {
                // Write index, word, and file count
                fprintf(fptr, "#%d;", i);
                fprintf(fptr, "%s;", main_temp->word);
                fprintf(fptr, "%d;", main_temp->file_count);

                // Traverse sub linked list (file details)
                S_node *sub_temp = main_temp->sub_link;

                while (sub_temp)
                {
                    // Write filename and word count
                    fprintf(fptr, "%s;%d;", sub_temp->filename, sub_temp->word_count);
                    sub_temp = sub_temp->sub_link; 
                }

                // Mark end of one word entry
                fprintf(fptr, "#\n"); 

                // Move to next word
                main_temp = main_temp->main_link;
            }
        }
    }

    // Close file after writing
    fclose(fptr);

    printf("\nINFO : Database saved successfully\n");
}