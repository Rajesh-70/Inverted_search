/*
------------------------------------------------------------
Author      : Durga Rajesh Bathula
Project Name: Inverted Search (Inverted Index using Hashing)
Date        : April 2026
Batch       : 25036A
------------------------------------------------------------

Description:

This project implements an Inverted Search system using 
Data Structures in C. The main goal of the project is to 
store and retrieve words efficiently from multiple text files.

The system uses a Hash Table (size 27) combined with 
Linked Lists to map words to the files in which they appear.

Working:
- Reads multiple .txt files
- Extracts words from each file
- Stores words in hash table using indexing (a–z)
- Each word is stored in a main node
- Each main node contains a sub linked list of file details
- Tracks:
    -> File name
    -> Word occurrence count

Features:
- Create database from input files
- Display database in structured format
- Search word and show file occurrences
- Save database into a file
- Update database with new file

Data Structures Used:
- Hash Table
- Singly Linked List (File List)
- Multi-level Linked List (Main + Sub nodes)

Applications:
- Search engines (basic concept)
- File indexing systems
- Text processing tools

------------------------------------------------------------
*/
#include "inverted.h"

// Flags to check whether database is created or updated
int create_flag = 0;
int update_flag = 0;

int main(int argc, char *argv[])
{
    // Head pointer for file linked list
    F_node *head = NULL;

    // Hash Table with 27 indexes (a-z + special)
    M_node *HT[27];

	// Initialize all hash table pointers to NULL
	for (int i = 0; i < 27; i++)
	{
		HT[i] = NULL;
	}

    // Validate input files from command line
	if(argc >= 2)
	{
		validate_files(argv, &head);
	}
	else
	{
		printf("-------------------------------------------------\n");
		printf("INFO : Insufficient arguments\n");
		printf("Please pass the arguments like ./a.out <txt file>\n");
		printf("-------------------------------------------------\n");
		return FAILURE;
	}

	// Print valid filenames and check if list is empty
	if (print_filenames(head) == FAILURE)
	{
		printf("ERROR : No valid files found\n");
		printf("Database creation is not possible\n-> NULL\n");
		return FAILURE;
	}

    int option;

    // Menu driven program
    do
    {
		printf("\nSelect your choice among following operations:\n");
		printf("1. Create Database\n2. Display Database\n3. Save Database\n");
		printf("4. Search\n5. Update Database\n6. Exit\n\n");
		printf("Enter your choice : ");
		scanf("%d", &option);
		
		switch (option)
		{
			case 1:
		        // Create inverted index database
		        create_database(HT, head);
				create_flag = 1;  // Mark database as created
		        break;

	        case 2:
			    // Display database only if created
			    if(!create_flag)
				{
					printf("\nDatabase not created yet Nothing to display!!\n");
				    break;
				}
		        display_database(HT);
		        break;

	        case 3:
			    // Save database to file
			    char file[50];
				printf("Enter the File name to save data : ");
				scanf("%s", file);
		        save_database(HT, file);
		        break;

	       case 4:
		        // Search for a word in database
		        char word[50];
		        printf("Enter the word to search : ");
				scanf("%s", word);
		        search_database(HT, word);
		        break;

	       case 5:
		        // Update database only if already created
		        if(!create_flag)
				{
					printf("\nDatabase not created yet Nothing to update!!\n");
					break;
				}
				create_flag = 0;   // Reset flag before update
				update_flag = 1;   // Mark update operation
		        update_database(HT, &head);
				create_flag = 1;   // Set again after update
		        break;

	       case 6:
		        // Exit the program
		        printf("\nThank you for using Inverted Search\nEXIT\n");
		        break;

	       default:
		        // Handle invalid option
		        printf("INFO : Please enter the valid option\n");
	    }

    } while(option != 6);  // Loop until user selects Exit

    return 0;
}