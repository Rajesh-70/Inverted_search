#include "inverted.h"

/* Function to search a word in the database */
void search_database(M_node *HT[], char *word)
{
    // Get hash index for the given word
    int index = get_index(word);

    // Traverse main linked list at that index
    while(HT[index] != NULL)
    {
        // Check if word matches
        while(!strcmp(HT[index]->word, word))
        {
            printf("===============================================\n");
            printf("FOUND AT : \n");

            // Print word details
            printf("%-10s : [%d]\n", "INDEX", index);
            printf("%-10s : %-15s\n", "WORD", HT[index]->word); 
            printf("%-10s : %-15d\n", "FILECOUNT", HT[index]->file_count);

            // Traverse sub linked list (file details)
            S_node *sub_temp = HT[index]->sub_link;

            while(sub_temp != NULL)
            {
                printf("%-10s : %-10s || %-10s : %-15d\n",
                        "FILENAME", sub_temp->filename,
                        "WORDCOUNT", sub_temp->word_count);

                sub_temp = sub_temp->sub_link;
            }

            printf("===============================================\n");

            return; // Exit after finding word
        }

        // Move to next main node (next word)
        HT[index] = HT[index]->main_link;
    }

    // If word not found
    printf("\nINFO : WORD IS NOT FOUND IN THE DATABASE\n");   
}