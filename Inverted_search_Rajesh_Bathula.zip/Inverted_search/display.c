#include "inverted.h"

// Function to display the inverted index database
void display_database(M_node *HT[])
{
    // Print table header
    printf("|-----------------------------------------------------------------------|\n");
    printf("| %-15s%-15s%-15s%-15s%-15s\n","INDEX","WORD","FILECOUNT","FILENAME","WORDCOUNT |");
    printf("|-----------------------------------------------------------------------|\n");

    // Traverse all 27 hash table indexes (a-z + special)
    for(int i = 0; i < 27; i++)
    {
        // Check if index contains any data
        if(HT[i] != NULL)
        {
            // Pointer to traverse main linked list (words)
            M_node *main_temp = HT[i];

            // Traverse main list (each word)
            while(main_temp != NULL)
            {
                // Pointer to traverse sub list (files)
                S_node *sub_temp = main_temp->sub_link;

                // Traverse sub list (file details)
                while (sub_temp != NULL)
                {
                    // Print index, word and file count only for first sub node
                    if(sub_temp == main_temp->sub_link)
                    {
                        printf("| %-15d", i);
                        printf("%-15s%-15d", main_temp->word, main_temp->file_count); 
                    }
                    else
                    {
                        // For remaining nodes, keep columns empty (format alignment)
                        printf("| %-15s", "");
                        printf("%-15s%-15s", "", "");
                    }

                    // Print filename and word count
                    printf("%-15s%-10d|\n", sub_temp->filename, sub_temp->word_count);

                    // Move to next sub node
                    sub_temp = sub_temp->sub_link;
                }

                // Move to next main node (next word)
                main_temp = main_temp->main_link; 
            }
        }
    }

    // Print table footer
    printf("|-----------------------------------------------------------------------|\n");
}