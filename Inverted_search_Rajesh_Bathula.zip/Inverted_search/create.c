#include "inverted.h"

// External flags to track database status
extern int create_flag;
extern int update_flag;


/* Function to create main node (word node) */
M_node *create_main_node(char *word, char *filename)
{
    // Allocate memory for main node
    M_node *new_main = malloc(sizeof(M_node));

    if(new_main == NULL)
    {
        return FAILURE; // Memory allocation failed
    }
    
    // Initialize main node data
    strcpy(new_main->word, word); 
    new_main->file_count = 1;          // First occurrence in one file
    new_main->main_link = NULL;

    // Create first sub node (file details)
    new_main->sub_link = create_sub_node(filename); 

    return new_main;
}


/* Function to create sub node (file node) */
S_node *create_sub_node(char *filename)
{
    // Allocate memory for sub node
    S_node *new_sub = malloc(sizeof(S_node));

    if(new_sub == NULL)
    {
        return FAILURE; // Memory allocation failed
    }

    // Initialize sub node data
    new_sub->word_count = 1;           // First occurrence of word
    strcpy(new_sub->filename, filename); 
    new_sub->sub_link = NULL;

    return new_sub;
}


/* Function to create inverted index database */
void create_database(M_node *HT[], F_node *head)
{
    // Check if database already created
    if(create_flag)
    {
        printf("INFO : Database is already created\n");
        return;
    }

    // Traverse file linked list
    while(head)
    {
        // Open each file
        FILE *fptr = fopen(head->f_name, "r");

        char str[25];

        // Read words one by one from file
        while (fscanf(fptr, "%s", str) == 1)
        {
            // Get hash index based on word
            int index = get_index(str);

            // If no word exists at this index
            if(HT[index] == NULL)
            {
                // Create new main node
                HT[index] = create_main_node(str, head->f_name);
            }
            else
            {
                // Traverse main linked list (words)
                M_node *temp = HT[index];
                M_node *prev = NULL;

                // Search for the word
                while(temp != NULL && strcmp(temp->word, str) != 0)
                {
                    prev = temp;
                    temp = temp->main_link;
                }

                // Word not found → create new main node
                if(temp == NULL)
                {
                    prev->main_link = create_main_node(str, head->f_name);
                }
                else
                {
                    // Word found → check sub list (files)
                    S_node *sub_temp = temp->sub_link;
                    S_node *sub_prev = NULL;

                    // Search for file in sub list
                    while(sub_temp != NULL && strcmp(sub_temp->filename, head->f_name) != 0)
                    {
                        sub_prev = sub_temp;
                        sub_temp = sub_temp->sub_link;
                    }

                    // File not found → create new sub node
                    if(sub_temp == NULL)
                    {
                        sub_prev->sub_link = create_sub_node(head->f_name);
                        temp->file_count++;   // Increase file count
                    }
                    else
                    {
                        // File found → increment word count
                        sub_temp->word_count++;
                    }
                }
            }
        }

        // Close file after processing
        fclose(fptr);

        printf("\nINFO : Successful : Creation of DATABASE for file : %s\n", head->f_name);

        // If update operation, process only one file
        if (update_flag)
        {
            break;
        }   

        // Move to next file
        head = head->link;
    }
}