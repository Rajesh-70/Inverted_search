#include "inverted.h"

/* Function to validate input files and store valid ones in linked list */
void validate_files(char *argv[], F_node **head)
{
    int i = 1;
    char *res = NULL;

    // Loop through all command line arguments
    while(argv[i])
    {
        // Check for file extension
        res = strstr(argv[i], ".");

        if(res)
        {
            // Check if extension is .txt
            if(strcmp(res, ".txt") == 0)
            {
                // Try to open file
                FILE *fptr = fopen(argv[i], "r");

                if(fptr)
                {
                    // Move to end to check file size
                    fseek(fptr, 0, SEEK_END);
                    unsigned size = ftell(fptr);
                    rewind(fptr);

                    // Check if file is not empty
                    if(size)
                    {
                        // Check for duplicate filenames
                        if (check_duplicates(*head, argv[i]) == FAILURE)
                        {
                            // Insert file into linked list
                            if (insert_last(head, argv[i]) == SUCCESS)
                            {
                                printf("INFO : Successful : Inserting file name %s into file linked list\n\n", argv[i]);
                            }
                        }
                        else
                        {
                            // Duplicate file case
                            printf("INFO : %s => This file is repeated, so it will not store into the sll\n\n", argv[i]);
                        }
                    }
                    else
                    {
                        // Empty file case
                        printf("INFO : %s => This file has no data\n\n", argv[i]);
                    }
                }
                else
                {
                    // File not found
                    printf("INFO : %s => This file does not exist in the current directory\n\n", argv[i]);
                }
            }
            else
            {
                // Invalid extension
                printf("INFO : %s => This file has invalid extension\n\n", argv[i]);
            }
        }
        else
        {
            // No extension case
            printf("INFO : %s => This file has without extension\n\n", argv[i]);
        }

        i++;
    }
}


/* Function to check duplicate filenames in linked list */
int check_duplicates(F_node *head, char *f_name)
{
    while(head != NULL)
    {
        // Compare filenames
        if(strcmp(head->f_name, f_name) == 0)
        {
            return SUCCESS; // Duplicate found
        }
        head = head->link;
    }
    return FAILURE; // No duplicate
}


/* Function to insert node at end of linked list */
int insert_last(F_node **head, char *f_name)
{
    // Allocate memory for new node
    F_node *new_node = malloc(sizeof(F_node));

    if (new_node == NULL)                      
    {
        return FAILURE;
    }

    // Copy filename and initialize link
    strcpy(new_node->f_name, f_name);
    new_node->link = NULL;    

    // If list is empty, insert as first node
    if (*head == NULL)    
    {            
        *head = new_node;
    }
    else
    {
        // Traverse till last node
        F_node *temp = *head;
        while (temp->link != NULL) 
        {
            temp = temp->link;
        }

        // Attach new node at end
        temp->link = new_node;
    }

    return SUCCESS;
}


/* Function to get hash index based on first character of word */
int get_index(char *word)
{
    // For lowercase letters
    if(word[0] >= 'a' && word[0] <= 'z')
    {
        return word[0] - 'a';
    }
    // For uppercase letters
    else if(word[0] >= 'A' && word[0] <= 'Z')
    {
        return word[0] - 'A';
    }
    else
    {
        // For special characters
        return 26;
    }
}


/* Function to print all filenames in linked list */
int print_filenames(F_node *head)
{
    // Check if list is empty
    if(head == NULL)
    {
        return FAILURE;
    }
    
    printf("\n>>> Valid input files selected for inverted index <<\n\n");

    // Traverse and print filenames
    while(head)
    {
        printf("%s -> ", head->f_name);
        head = head->link;
    }

    printf("NULL\n");
    return SUCCESS;
}


/* Function to insert node at beginning of linked list */
int insert_first(F_node **head, char *filename)
{
    // Allocate memory
    F_node *new_node = malloc(sizeof(F_node)); 

    if (new_node == NULL)
    {
        return FAILURE;
    }

    // Initialize node data
    strcpy(new_node->f_name, filename);
    new_node->link = NULL; 

    // Insert at beginning
    new_node->link = *head;
    *head = new_node; 

    return SUCCESS; 
}