#ifndef INVERTED_H
#define INVERTED_H

// Standard libraries
#include<stdio.h>
#include<string.h>
#include<stdlib.h>

// Macros for status
#define SUCCESS 1
#define FAILURE 0


/* Structure to store file names (File Linked List) */
typedef struct file
{
    char f_name[20];        // Name of the file
    struct file *link;      // Pointer to next file
} F_node;


/* Structure to store file details for each word (Sub Linked List) */
typedef struct Sub
{
    int word_count;         // Number of times word appears in this file
    char filename[20];      // File name
    struct Sub *sub_link;   // Pointer to next sub node
} S_node;


/* Structure to store words (Main Linked List for each index) */
typedef struct Main
{
    char word[25];          // Word
    int file_count;         // Number of files containing this word
    S_node *sub_link;       // Link to sub list (file details)
    struct Main *main_link; // Pointer to next word
} M_node;


/* ----------- Function Declarations ----------- */

// Create inverted index database
void create_database(M_node *HT[], F_node *head);

// Display the database
void display_database(M_node *HT[]);

// Search for a word in database
void search_database(M_node *HT[], char *word);

// Save database to a file
void save_database(M_node *HT[], char *file);

// Update database with new files
int update_database(M_node *HT[], F_node **head);


// Create main node (word node)
M_node *create_main_node(char *word, char *filename);

// Create sub node (file node)
S_node *create_sub_node(char *filename);


// Validate input files
void validate_files(char *argv[], F_node **head);

// Insert file at end of list
int insert_last(F_node **head, char *f_name);

// Check duplicate filenames
int check_duplicates(F_node *head, char *f_name);

// Print all filenames
int print_filenames(F_node *head);

// Get hash index based on word
int get_index(char *word);

// Insert file at beginning
int insert_first(F_node **head, char *filename);

#endif